# cs3500animation
<h2> Interfaces </h2>
<h3>AnimatorModel</h3>
<h3>AnimatorModelState</h3>
<h3>IShape</h3>

<h2> Classes </h2>
<h3>AShape</h3>
<h3>Circle</h3>
<h3>Rect</h3>
<h3>Coordinate</h3>
<h3>SimpleAnimatorModelImpl</h3>

