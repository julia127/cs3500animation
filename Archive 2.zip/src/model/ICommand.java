package model;

import java.awt.*;

public interface ICommand {

  // getters

  // For a motion (transformation), there should be a starting value and an ending value.

  // transformation methods (motion)
  /** transformation method.
   * Change the position of a shape in the animation.
   *
   * @param coord the new position of the shape.
   */
  void move(Coordinate coord);

  /** transformation method.
   * Change the size of a shape in the animation.
   *
   * @param width the new width of the shape.
   * @param height the new height of the shape.
   */
  void changeSize(int width, int height);

  /** transformation method.
   * Change the color of a shape in the animation.
   *
   * @param color the color the shape will be changed to.
   */
  void changeColor(Color color);

  void executeCommand();

  IShape getMovingShape();

  int getStartingTick();

  int getEndingWidth();

  int getEndingHeight();


}