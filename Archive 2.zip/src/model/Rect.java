package model;

import java.awt.*;

public class Rect extends AShape {

  public Rect(String name, Coordinate coord, Color color, int width, int height) {
    super(color, coord, width, height);
    this.shapeType = ShapeType.RECTANGLE;
    this.shapeName = name;
  }

}
