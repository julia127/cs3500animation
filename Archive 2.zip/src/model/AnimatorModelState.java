package model;

public interface AnimatorModelState<K> {

  int getNumShapes();

  int getCommands();
}
