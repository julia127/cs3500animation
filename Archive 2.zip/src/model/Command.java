package model;

import java.awt.Color;

public class Command implements ICommand{

  private IShape movingShape;
  private int startingTick;
  private int endingWidth;
  private int endingHeight;
  private Coordinate endingCoord;
  private Color endingColor;
  private int endingTick;

  public Command(IShape movingShape, int startingTick, int endingTick) {
    IShape dupeMovingShape = new AShape(movingShape.getColor(), movingShape.getPosition(), movingShape.getWidth(),
        movingShape.getHeight());
    this.movingShape = movingShape;
    this.startingTick = startingTick;
    this.endingTick = endingTick;
    this.endingHeight = dupeMovingShape.getHeight();
    this.endingWidth = dupeMovingShape.getWidth();
    this.endingCoord = dupeMovingShape.getPosition();
    this.endingColor = dupeMovingShape.getColor();
  }

  @Override
  public void move(Coordinate coord) {
    this.endingCoord = coord;
  }

  @Override
  public void changeSize(int width, int height) {
    this.endingHeight = height;
    this.endingWidth = width;
  }

  @Override
  public void changeColor(Color color) {
    this.endingColor = color;
  }

  public void executeCommand() {
    movingShape.moveShape(endingCoord);
    movingShape.setHeight(endingHeight);
    movingShape.setWidth(endingWidth);
    movingShape.changeColor(endingColor);
  }

  public IShape getMovingShape() {
    return movingShape;
  }

  public int getStartingTick() {
    return startingTick;
  }

  public int getEndingWidth() {
    return endingWidth;
  }

  public int getEndingHeight() {
    return endingHeight;
  }

  public Coordinate getEndingCoord() {
    return endingCoord;
  }

  public Color getEndingColor() {
    return endingColor;
  }

  public int getEndingTick() {
    return endingTick;
  }
}
